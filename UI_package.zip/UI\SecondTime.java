package UI;

public class SecondTime extends ProjectUs {
    @Override
    public void launch() throws InterruptedException {
        System.out.println("Launching Us v2.0 with extra love ❤\n");
        super.launch();
    }

    public void specialMessage() {
        System.out.println("\n Welcome to Us v2.0 – smoother, happier, with you");
    }
}