package UI;

public class Loading {
    public static void show() throws InterruptedException {
        for(int i = 0; i <= 100; i += 20) {
            System.out.print("Loading: " + i + "% ");
            for(int j = 0; j < i / 10; j++) System.out.print("❤");
            System.out.println();
            Thread.sleep(300);
        }
    }
}
