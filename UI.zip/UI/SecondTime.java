package UI;

public class SecondTime extends ProjectUs {
    @Override
    public void launch() {
        System.out.println("Launching Us v2.0 with extra care ❤\n");
        super.launch();
    }

    public void specialMessage() {
        System.out.println("\nWelcome to Us v2.0 – smoother, happier, with you");
    }
}