package UI;

import java.util.*;

public class ProjectUs {
    private String version = "2.0";
    private int pahinga = 0;
    private int care = 100;
    private String[] careMessages = {
            "Thinking of u",
            "Ready... for i?",
            "u + i = ❤"
    };

    public void debugPast(){
        System.out.println("Analyzing previous version...");
        System.out.println("Found bugs: misunderstanding, silence, missed chances...");
        System.out.println("Fixes applied\n");
    }

    public void launch() {
        System.out.println("Launching Us v" + version);
        Loading.show();

        pahinga += 100;
        System.out.println("\nPahinga level: " + pahinga);
        System.out.println("\nCare level: " + care + "\n");

        System.out.println("Messages while launching:");
        for(String msg : careMessages) {
            System.out.println(msg);
        }

        Scanner scanner = new Scanner(System.in);
        String response = " ";
        while(!response.equalsIgnoreCase("ou")){
            System.out.println("\nDo you want to run a second time with me?(type 'ou')");
            response = scanner.nextLine().trim();
        }

        System.out.println("\nSecond chance accepted! Let’s make it amazing together!");
    }
}