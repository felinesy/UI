package UI;

public class UsV2 {
    public static void main(String[] feline) {
        SecondTime projectUs = new SecondTime();
        projectUs.debugPast();
        projectUs.launch();
        projectUs.specialMessage();
    }
}